function updateLGD(input_value) {
  document.getElementById('selected-lgd').value = input_value;
}

function updateEAD(input_value) {
  document.getElementById('selected-ead').value = input_value;
}

function resetForm() {
  document.getElementById('selected-lgd').value = 0;
  document.getElementById('lgd-slider').value = 0;

  document.getElementById('selected-ead').value = 0;
  document.getElementById('ead-slider').value = 0;

  document.getElementById('csv-file').value = null;

}

window.onload = function () {
  // resets slides on page load or refresh
  document.getElementById('lgd-slider').value = 0;
  document.getElementById('ead-slider').value = 0;

  // resets the csv file to be uploaded
  document.getElementById('csv-file').value = null;

  console.log("all loaded")
}
