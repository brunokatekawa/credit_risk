# data manipulation
import json
import os
import pandas as pd
from utils import DecimalEncoder, prepare_data_for_calculation, calculate_total_expected_loss

# routes and page rendering
from flask import Flask, render_template, session, redirect, url_for

# form
from forms import RiskParametersForm

# machine learning
from preprocessors import Pipeline

# creates the app and sets configs
app = Flask(__name__)
app.config['SECRET_KEY'] = 'creditriskapp'

# instantiate the data pipeline
pipeline = Pipeline()


@app.route('/', methods=['GET', 'POST'])
def index():
    # creates an instance of the form
    form = RiskParametersForm()

    # if form is valid on submission
    if form.validate_on_submit():
        session['lgd'] = json.dumps(
            form.lgd.data, cls=DecimalEncoder)

        session['ead'] = json.dumps(
            form.ead.data, cls=DecimalEncoder)

        # stores the CSV as a pandas DataFrame
        df_raw = pd.read_csv(form.file.data)

        # makes the predictions
        predictions = pipeline.predict(df_raw)

        # calculates the total expected_loss
        total_expected_loss = calculate_total_expected_loss(df_raw,
                                                            predictions,
                                                            session['lgd'],
                                                            session['ead'])

        session['total_expected_loss'] = "${:,.2f}".format(total_expected_loss)

        return redirect(url_for("results"))

    return render_template("index.html", form=form)


@app.route('/results')
def results():

    return render_template("results.html")


if __name__ == "__main__":
    port = os.environ.get('PORT', 5000)
    app.run(host='0.0.0.0', port=port)
