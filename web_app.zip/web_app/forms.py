# forms
from flask_wtf import FlaskForm
from flask_wtf.file import FileField
from wtforms import SubmitField
from wtforms.fields.html5 import DecimalRangeField
from wtforms.validators import DataRequired


class RiskParametersForm(FlaskForm):
    lgd = DecimalRangeField('Loss Given Default', id='lgd-slider', default=0)
    ead = DecimalRangeField('Exposure at Default', id='ead-slider', default=0)
    file = FileField('CSV File', id='csv-file', validators=[DataRequired()])
    submit = SubmitField('Calculate')
