# data manipulation
import json
from decimal import Decimal
import pandas as pd
import numpy as np


class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return json.JSONEncoder.default(self, obj)


def prepare_data_for_calculation(data_frame, probs):

    # defines probabilities Data Frame
    df_probs = pd.DataFrame(probs[:, 1])
    df_probs.columns = ['prob_default']

    # concatenates the probabilities with the respective loan amount
    df_prep = pd.concat(
        [df_probs, data_frame[['loan_amnt']].reset_index()], axis=1)

    # drops unused column
    df_prep.drop('index', axis=1, inplace=True)

    return df_prep


def calculate_total_expected_loss(data_frame, probs, lgd, ead):

    # calls the function to prepare the Data Frame
    data = prepare_data_for_calculation(data_frame, probs)

    # sets the loss given default
    data['loss_given_default'] = float(lgd)

    # calculates the bank's expected loss and assign it to a new column
    data['expected_loss'] = data['prob_default'] * \
        data['loss_given_default'] * (data['loan_amnt'] * float(ead))

    # calculates the total expected loss to two decimal places
    total_exp_loss = round(np.sum(data['expected_loss']), 2)

    return total_exp_loss
