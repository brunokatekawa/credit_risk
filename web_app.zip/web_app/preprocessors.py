# data manipulation
import pickle
import pandas as pd
import numpy as np

# data transformation
from sklearn.preprocessing import MinMaxScaler


class Pipeline(object):

    def __init__(self):
        # sets the home path
        self.home_path = ''

        # loads model
        self.model = pickle.load(
            open(self.home_path + 'model/model_credit_risk.pkl', 'rb'))

        # instantiates the scaler
        self.scaler = MinMaxScaler()

    # scales and encodes the data
    def transform(self, input_data):
        data = input_data.copy()

        ##########################
        # SCALING NUMERICAL VARS #
        ##########################

        # selects only numerical data types variables
        df_numerical_vars = data.select_dtypes(
            include=['int64', 'float64']).drop('loan_status', axis=1)

        # applies the scaler
        scaled_numerical = self.scaler.fit_transform(df_numerical_vars)

        # gets the Data Frame version of numerical scaled for later manipulation
        df_scaled_numerical = pd.DataFrame(scaled_numerical)

        # renaming the columns of result Data Frame
        df_scaled_numerical.columns = df_numerical_vars.columns

        #############################
        # ENCODING CATEGORICAL VARS #
        #############################

        # creates data sets for non-numeric data
        cred_str = data.select_dtypes(include=['object'])

        # One-hot encode the non-numeric columns
        cred_str_onehot = pd.get_dummies(cred_str)

        # union the one-hot encoded columns to the numeric ones
        df_cr_loan_prep = pd.concat(
            [df_scaled_numerical, cred_str_onehot], axis=1)

        return df_cr_loan_prep

    def predict(self, input_data):
        transformed_data = self.transform(input_data)

        predictions = self.model.predict_proba(transformed_data)

        return predictions
